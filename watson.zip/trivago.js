/*I ask node.js to get the axios*/
const axios = require('axios');
var qs = require('qs');

function Trivago() {
    data = qs.stringify({
        
    });
}


